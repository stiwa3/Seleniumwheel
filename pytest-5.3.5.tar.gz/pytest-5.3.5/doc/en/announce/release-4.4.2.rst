pytest-4.4.2
=======================================

pytest 4.4.2 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at https://docs.pytest.org/en/latest/changelog.html.

Thanks to all who contributed to this release, among them:

* Allan Lewis
* Anthony Sottile
* Bruno Oliveira
* DamianSkrzypczak
* Daniel Hahler
* Don Kirkby
* Douglas Thor
* Hugo
* Ilya Konstantinov
* Jon Dufresne
* Matt Cooper
* Nikolay Kondratyev
* Ondřej Súkup
* Peter Schutt
* Romain Chossart
* Sitaktif


Happy testing,
The pytest Development Team
