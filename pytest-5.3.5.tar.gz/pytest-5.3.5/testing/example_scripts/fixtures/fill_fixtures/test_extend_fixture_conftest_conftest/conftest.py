import pytest


@pytest.fixture
def spam():
    return "spam"
