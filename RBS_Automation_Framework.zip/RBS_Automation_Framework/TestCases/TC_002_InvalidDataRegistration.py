"""
from Base import initiatedriver
def test_registration_invalid_data():
    driver = initiatedriver.startBrowser()
    driver.find_element_by_name('fld_password').send_keys('pwd')
    driver.current_url

"""