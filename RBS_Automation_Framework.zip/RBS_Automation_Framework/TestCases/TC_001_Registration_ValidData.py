from Base import *
from Base.initiatedriver import closeBrowser
from Library import ConfigReader

def test_ValidateRegistration():
    driver = initiatedriver.startBrowser()
    driver.find_element_by_name(ConfigReader.fetchElementLocator('Registration' , 'username_locator')).send_keys('Hellow')
    driver.find_element_by_name(ConfigReader.fetchElementLocator('Registration' , 'email_locator')).send_keys('abcd')
    #closeBrowser()
