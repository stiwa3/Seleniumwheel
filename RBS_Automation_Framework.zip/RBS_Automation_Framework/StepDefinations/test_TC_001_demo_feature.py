from pytest_bdd import *
import pytest
# Scenarios
from Library.test_dataReconcillation import DataValidation
import pytest_html
#from TestCases.TC_001_Registration_ValidData import test_ValidateRegistration

scenarios('../features/demo.feature')

@given('The user should succefully done with registration')
def ValidateRegistration():
    print('high')
    DataValidation()