from Base import *
import pandas as pd
import time
import pytest
import pytest_html

def DataValidation():
    # Read the Actual csv data
    actualDF = pd.read_csv(r'./TestData/ActualData.csv')

    # Read the Expected csv data
    ExpectedDF = pd.read_csv(r'./TestData/ExpectedData.csv')

    # Get the column header of an expected DataFrame as a list
    expectedDFColumnHeader = list(ExpectedDF.columns.values)

    # Get the column header of an Actual DataFrame as a list
    actualDFColumnHeader = list(actualDF.columns.values)

    # Get the mismatched column in between the expected and actual dataframe into alist.


    reconcilleActualDFColumns = list(set(actualDFColumnHeader) - set(expectedDFColumnHeader))

    # Remove the extra columns from a actual dataframe
    actualDFWithReconcilleExpectedColumnData = actualDF.drop(reconcilleActualDFColumns, axis=1)

    #Filtered operation
    filteredActualDf = actualDFWithReconcilleExpectedColumnData.loc[(actualDF['Num'] >= 7.6) & (actualDF['Color'] == 'Green')]
    df_diff = pd.concat([filteredActualDf, ExpectedDF]).drop_duplicates(keep=False)
    assert "Data is not get reconcile"
    assert df_diff




