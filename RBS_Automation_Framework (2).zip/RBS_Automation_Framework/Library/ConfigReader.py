import configparser
def readConfigData(section,key):
    config=configparser.ConfigParser()
    config.read('./ConfigFiles/config.cfg')
    return config.get(section,key)

def fetchElementLocator(section,key):
    config=configparser.ConfigParser()
    config.read('./ConfigFiles/elements.cfg')
    return config.get(section,key)
