from Library import ConfigReader

def test_enteruserid(driver):
    #driver = initiatedriver.startBrowser()
    driver.find_element_by_name(ConfigReader.fetchElementLocator('Registration' , 'username_locator')).send_keys('Hellow')


def test_enter_emailid(driver):
    driver.find_element_by_name(ConfigReader.fetchElementLocator('Registration', 'email_locator')).send_keys('abcd')
