from  selenium.webdriver import Chrome
from Library import ConfigReader
def startBrowser():
    global driver
    chrome_executable_driver_path = ("D:\\RBS\\chromedriver.exe")
    driver = Chrome(executable_path=chrome_executable_driver_path)
    driver.get(ConfigReader.readConfigData('Details' , 'Application_URL'))
    driver.maximize_window()
    return  driver

def closeBrowser():
    driver.close()
