from behave import *

from Library import ConfigReader
import time

from TestCases.TC_001_Registration_ValidData import *


@given(u'user is on Registration page')
def step_impl(context):
    context.driver.get(ConfigReader.readConfigData('Details', 'Application_URL'))
    context.driver.maximize_window()



@when(u'user enters username')
def step_impl(context):
    test_enteruserid(context.driver)

@when(u'user enters email id')
def step_impl(context):
    test_enter_emailid(context.driver)
    time.sleep((10))


'''
@when(u'user enters password')
def step_impl(context):
    context.driver.find_element_by_name('fld_password').send_keys('pwd')


@when(u'user enter on signup button')
def step_impl(context):
    raise NotImplementedError(u'STEP: When user enter on signup button')


@then(u'user should be registered succesfully')
def step_impl(context):
    raise NotImplementedError(u'STEP: Then user should be registered succesfully')
'''