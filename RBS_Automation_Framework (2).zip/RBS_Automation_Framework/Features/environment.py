from selenium.webdriver import Chrome
import time
from Library import ConfigReader
def before_all(context):
    chrome_executable_driver_path = ("./BrowserDriver/chromedriver.exe")
    context.driver = Chrome(executable_path=chrome_executable_driver_path)

def after_all(context):
    context.driver.close()
