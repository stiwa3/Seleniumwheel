==============
allure2-behave
==============

allure2-behave library - is Behave framework and Allure framework adapter. All information for report collect in environments.py file, see usage example_. allure-report folder, appeared after all tests complete.

for installation make:

.. code-block:: bash

    pip install allure2-behave

Source code page: source_

.. _source: https://github.com/DaulGitHub/allure-behave
.. _example: https://github.com/DaulGitHub/allure-behave/tree/master/example/features