This directory contains python package requirements for behave.
These requirement files are used by:

  * pip
  * tox
