New and Noteworthy
==============================================================================

In the good tradition of the `Eclipse IDE`_,
a number of news, changes and improvements are described here to provide
better background information about what has changed and how to make use of it.

This page orders the information by newest version first.

.. _`Eclipse IDE`:  http://www.eclipse.org/

.. toctree::
   :maxdepth: 2

   new_and_noteworthy_v1.2.5
   new_and_noteworthy_v1.2.4

